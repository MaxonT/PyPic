# PyPIC — Especificación integral

Documentación de diseño consolidada a partir de las decisiones y propuestas discutidas. **Estado: planificación; no es software implementado.**

**Decisión no negociable:** PyPIC adopta la **sintaxis** de Python para escribir firmware compilado a código máquina nativo. **Nunca** se busca llevar un intérprete Python al microcontrolador.

## Documentos
- [Principio arquitectónico: NO intérprete Python](00_PRINCIPIOS_NO_INTERPRETE.md)
- [Visión y alcance](01_VISION.md)
- [Compilador, IR y generación de código](02_COMPILADOR.md)
- [Device Packs y compatibilidad](03_DISPOSITIVOS.md)
- [VS Code, Wizard y perfiles](04_IDE_WIZARD.md)
- [SDK, librerías y programación visual](05_SDK.md)
- [Simulador y depuración](06_SIMULADOR_DEBUG.md)
- [I²C Scanner, terminal y herramientas de hardware](07_HERRAMIENTAS.md)
- [CLI, estructura de proyecto y contratos](08_CLI_FORMATOS.md)
- [Roadmap, pruebas y criterios de aceptación](09_ROADMAP.md)
- [Instrucciones para Codex](AGENTS.md)
- [Backlog de implementación](TASKS.md)

## Decisiones firmes
- Toolchain PyPIC Native independiente y predeterminado.
- Subconjunto Python compilado AOT, no intérprete.
- PIC16F887 primero, PIC12F625 después.
- Extensibilidad mediante IR, backends y Device Packs.
- Integración opcional con XC8/PIC-AS/SDCC mediante transpilación o ASM.
- VS Code, Wizard, pinout, simulador, debugger, I²C Scanner y terminal serial forman parte de la visión.

## Nota
Los prototipos UI y snippets anteriores son ilustrativos. Las APIs, versiones y capacidades deberán verificarse en implementación.
